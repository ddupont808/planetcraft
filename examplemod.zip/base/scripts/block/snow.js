block.material = materials.get("base:block/snow");

language.add(block.id, 'en_us', 'Snow');