block.material = materials.get("base:block/oak_leaves");

language.add(block.id, 'en_us', 'Oak Leaves');