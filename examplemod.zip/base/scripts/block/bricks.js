block.material = materials.get("base:block/bricks");

language.add(block.id, 'en_us', 'Bricks');