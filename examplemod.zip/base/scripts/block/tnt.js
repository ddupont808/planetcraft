block.material = materials.get("base:block/tnt");

language.add(block.id, 'en_us', 'TNT');