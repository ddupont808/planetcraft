block.material = materials.get("base:block/bedrock");

language.add(block.id, 'en_us', 'Bedrock');