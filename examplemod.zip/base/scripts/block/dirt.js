block.material = materials.get("base:block/dirt");

language.add(block.id, 'en_us', 'Dirt');