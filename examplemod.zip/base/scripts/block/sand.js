block.material = materials.get("base:block/sand");

language.add(block.id, 'en_us', 'Sand');