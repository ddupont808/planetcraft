block.material = materials.get("base:block/crafting_table");

language.add(block.id, 'en_us', 'Crafting Table');