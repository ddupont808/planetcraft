block.material = materials.get("base:block/glass");

language.add(block.id, 'en_us', 'Glass');