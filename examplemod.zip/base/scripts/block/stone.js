block.material = materials.get("base:block/stone");

language.add(block.id, 'en_us', 'Stone');