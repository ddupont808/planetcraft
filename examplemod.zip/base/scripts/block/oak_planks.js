block.material = materials.get("base:block/oak_planks");

language.add(block.id, 'en_us', 'Oak Planks');