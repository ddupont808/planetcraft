block.material = materials.get("base:block/diamond_ore");

language.add(block.id, 'en_us', 'Diamond Ore');