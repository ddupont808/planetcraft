block.material = materials.get("base:block/grass_snow");

language.add(block.id, 'en_us', 'Frozen Grass');