block.material = materials.get("base:block/cobblestone");

language.add(block.id, 'en_us', 'Cobblestone');