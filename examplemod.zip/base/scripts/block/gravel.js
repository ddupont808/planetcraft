block.material = materials.get("base:block/gravel");

language.add(block.id, 'en_us', 'Gravel');