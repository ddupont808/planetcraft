block.material = materials.get("base:block/grass");

function supportsGrowth(world, pos) {
    return !world.isFull(pos);
}

block.onRandomTick = (world, pos) => {
    if(world.isServer) {
        var adj_x = (Math.random() * 3) - 1;
        var adj_y = (Math.random() * 3) - 1;
        var adj_z = (Math.random() * 3) - 1;
        var adj_pos = pos.add(adj_x, adj_y, adj_z);

        if(world.getBlock(adj_pos) == 'base:block/dirt' && supportsGrowth(adj_pos)) {
            world.setBlock(adj_pos, block.id);
        }
    }
};

language.add(block.id, 'en_us', 'Grass');