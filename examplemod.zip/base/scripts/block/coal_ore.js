block.material = materials.get("base:block/coal_ore");

language.add(block.id, 'en_us', 'Coal Ore');