block.material = materials.get("base:block/clay");

language.add(block.id, 'en_us', 'Clay');