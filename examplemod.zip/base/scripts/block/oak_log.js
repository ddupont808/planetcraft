block.material = materials.get("base:block/oak_log");

language.add(block.id, 'en_us', 'Oak Log');