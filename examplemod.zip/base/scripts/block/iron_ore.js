block.material = materials.get("base:block/iron_ore");

language.add(block.id, 'en_us', 'Iron Ore');