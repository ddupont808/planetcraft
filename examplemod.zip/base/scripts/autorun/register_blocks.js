import * as assetRegistry from 'internal/assetRegistry';
Promise.all(
    assetRegistry.blocks.map(
        async(blockId) => blocks.add(blockId, (await import(blockId)).block)
    )
).then(() => events.emit('blocks.registered'));